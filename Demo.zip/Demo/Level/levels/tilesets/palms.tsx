<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="palms" tilewidth="128" tileheight="136" tilecount="3" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="80" height="103" source="../../graphics/terrain/palm_small/small_1.png"/>
 </tile>
 <tile id="1">
  <image width="78" height="136" source="../../graphics/terrain/palm_large/large_1.png"/>
 </tile>
 <tile id="2">
  <image width="128" height="128" source="../../graphics/terrain/palm_bg/bg_palm_1.png"/>
 </tile>
</tileset>
